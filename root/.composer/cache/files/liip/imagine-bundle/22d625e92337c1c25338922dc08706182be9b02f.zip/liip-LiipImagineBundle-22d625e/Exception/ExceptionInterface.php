<?php

namespace Liip\ImagineBundle\Exception;

interface ExceptionInterface
{
}
