<?php

namespace Liip\ImagineBundle\Exception\Imagine\Cache\Resolver;

use Liip\ImagineBundle\Exception\ExceptionInterface;

class NotResolvableException extends \RuntimeException implements ExceptionInterface
{
}
